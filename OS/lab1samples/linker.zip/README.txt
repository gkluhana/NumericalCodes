Zip file includes linker.cpp and makefile.

Compiler version used: g++ (Ubuntu/Linaro 4.4.7-8ubuntu1) 4.4.7

make should be able to generate executable which can be run by: (assuming current directory contains another directory named outputs )

./runit.sh outputs ./linker
./gradeit.sh . outputs


Files were tested on courses2 and compiled without errors.



