Zip file includes mmu.cpp and makefile.

Compiler version used: g++ (Ubuntu/Linaro 4.4.7-8ubuntu1) 4.4.7

make should be able to generate executable which can be run by: (assuming current directory contains another directory named outputdir, and mmu is in same directory)

/runit.sh inputdir outputdir ./mmu
/diffit.sh refout outputdir

Files were tested on courses2 and compiled without errors.


