Zip file includes scheduler.cpp and makefile.

Compiler version used: g++ (Ubuntu/Linaro 4.4.7-8ubuntu1) 4.4.7

make should be able to generate executable which can be run by: (assuming current directory contains another directory named outputdir, and sched is moved to src folder)

/runit outputdir ./src/sched
/diffit.sh refout outputdir

Files were tested on courses2 and compiled without errors.



